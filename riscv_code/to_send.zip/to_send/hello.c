#include<stdio.h>
int main() 
{
  int a = 32; 
  int b = a * 32;
  int c = b;
  
  //printf("c=%c",c);z
  
}
